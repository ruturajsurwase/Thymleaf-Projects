let currentIndex = 0;
const images = document.querySelectorAll('.gallery-item img');
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightbox-image');

// Open lightbox with selected image
function openLightbox(index) {
    currentIndex = index;
    lightboxImage.src = images[currentIndex].src;
    lightbox.style.display = 'flex';
}

// Close lightbox
function closeLightbox() {
    lightbox.style.display = 'none';
}

// Change to next or previous image
function changeImage(direction) {
    currentIndex = (currentIndex + direction + images.length) % images.length;
    lightboxImage.src = images[currentIndex].src;
}
