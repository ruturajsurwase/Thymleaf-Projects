package com.construction;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController 
{

	@GetMapping("/index")
	public String indexPage() {
		return "index";
	}

	@GetMapping("/aboutUs")
	public String aboutUsPage() {
		return "aboutUs";
	}

	@GetMapping("/services")
	public String servicesPage() {
		return "Services";
	}

	@GetMapping("/gallery")
	public String galleryPage() {
		return "gallery";
	}
	

	@GetMapping("/contactUs")
	public String contactPage() {
		return "contactUs";
	}
	
}
