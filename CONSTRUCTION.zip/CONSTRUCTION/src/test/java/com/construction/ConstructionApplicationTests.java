package com.construction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConstructionApplicationTests {

	@Test
	void contextLoads() {
	}

}
